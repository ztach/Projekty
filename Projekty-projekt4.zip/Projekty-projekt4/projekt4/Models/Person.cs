﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace projekt4.Models
{
    public class Person
    {
        public string Imie { get; set; }
        public string Nazwisko { get; set; }
        public int Age { get; set; }
        /*
        public Person(string sImie, string sNazwisko, int iAge)
        {
            Imie = sImie;
            Nazwisko = sNazwisko;
            Age = iAge;
        }
        */

    }
}